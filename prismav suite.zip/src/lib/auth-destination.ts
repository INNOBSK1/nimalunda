export function authDestination(user: unknown): '/' | null {
  return user ? '/' : null;
}